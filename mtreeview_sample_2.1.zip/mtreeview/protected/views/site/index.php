<?php $this->pageTitle=Yii::app()->name; ?>

<h2>MTreeView</h2>
<p> <a href="http://macinville.blogspot.com/">MTreeView</a> extends <a href="http://www.yiiframework.com/doc/api/1.1/CTreeView">CTreeView</a>, which displays a tree view of hierarchical data. It can handle both nested set and adjacency hierarchy model,and can create a linked node and adds icon if you wish. It can also be used to render AJAX tree! </p>
<p>To start viewing the examples, create a database named <strong>'mtreedb'</strong> then import the SQL file inside the <strong>/protected/data</strong> folder. </p>
<p>Comments and suggestions are very much welcome.</p>
<p>Links:</p>
<p><a href="http://macinville.blogspot.com/2011/07/managing-nested-setadjacency-models-yii.html">Explanation about the extension</a></p>
<p><a href="http://macinville.blogspot.com/2011/07/managing-nested-setadjacency-models-yii.html#downloads">Downloadables</a></p>
<p><a href="http://www.yiiframework.com/extension/mtreeview/">Extension Page</a></p>
<p><a href="http://www.yiiframework.com/forum/index.php?/topic/21403-mtreeview/">Discussion Page</a></p>
